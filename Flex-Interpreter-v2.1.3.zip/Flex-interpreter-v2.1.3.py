﻿# flex_interpreter.py

import importlib
import sys
import tkinter as tk
import tkinter.messagebox
import pyautogui
import time

# Environment untuk Flex
flex_env = {
    "saytxt": print,
    "saynum": print,
    "inputplyr": lambda: input(">> ")
}

# Built-in libraries
built_in_libs = {
    "math": {
        "add": lambda a, b: a + b,
        "sub": lambda a, b: a - b,
        "mul": lambda a, b: a * b,
        "div": lambda a, b: a / b,
        "sqrt": lambda x: x ** 0.5,
        "pow": lambda a, b: a ** b
    },
    "text": {
        "toupper": lambda s: s.upper(),
        "tolower": lambda s: s.lower(),
        "length": lambda s: len(s),
        "concat": lambda a, b: a + b
    },
    "spcl": {
        "greet": lambda name: print(f"Special hello, {name}!")
    },
    "FlexGUI": {
        "move_mouse": lambda x, y: pyautogui.moveTo(x, y),
        "show_popup": lambda msg: tk.Tk().withdraw() or tk.messagebox.showinfo("FlexGUI", msg),
        "flash_screen": lambda times: [flash_once() for _ in range(times)]
    },
    "TXTtoNUM": {
        "convert": lambda s: int(s) if s.isdigit() else float(s) if s.replace('.', '', 1).isdigit() else 0
    },
    "AutoInput": {
        "reply": lambda prompt: auto_reply(prompt)
    },
    "PopUPMes": {
        "alert": lambda msg: tk.Tk().withdraw() or tk.messagebox.showerror("Alert", msg)
    }
}

# Simple auto-reply logic
simple_replies = {
    "apa kabar": "Saya baik, terima kasih!",
    "siapa kamu": "Saya Flex AI.",
    "halo": "Halo juga!"
}

def auto_reply(prompt):
    prompt = prompt.lower()
    for key in simple_replies:
        if key in prompt:
            return simple_replies[key]
    return "Maaf, saya tidak mengerti."

# Function to flash screen (simple console-based simulation)
def flash_once():
    print("\033[?5h", end="")  # Enable reverse video mode (flashing)
    time.sleep(0.2)
    print("\033[?5l", end="")  # Disable reverse video mode
    time.sleep(0.2)

# Track loaded libraries
loaded_libraries = set()

# Temporary storage for function definitions
custom_functions = {}

def load_library(name):
    lib = built_in_libs.get(name)
    if lib:
        flex_env.update(lib)
        loaded_libraries.add(name)
        print(f"Library '{name}' loaded.")
    else:
        print(f"Library '{name}' not found.")

def unload_library(name):
    if name in loaded_libraries:
        for key in built_in_libs.get(name, {}).keys():
            flex_env.pop(key, None)
        loaded_libraries.remove(name)
        print(f"Library '{name}' unloaded.")
    else:
        print(f"Library '{name}' is not loaded.")

def parse_block(lines, start_index):
    block = []
    i = start_index
    while i < len(lines):
        line = lines[i].strip()
        if line == "}" or line == "}end":
            break
        block.append(line)
        i += 1
    return block, i

def run_line(line):
    line = line.strip()
    if line.startswith("load "):
        libname = line.split(" ")[1]
        load_library(libname)
    elif line.startswith("Loadspcl"):
        load_library("spcl")
    elif line.startswith("LoadDel"):
        parts = line.split(" ")
        if len(parts) > 1:
            unload_library(parts[1])
        else:
            print("[Syntax Error] Library name required after LoadDel")
    elif line.startswith("let ") or line.startswith("varble "):
        try:
            keyword, rest = line.split(" ", 1)
            var_name, expression = rest.split("=", 1)
            var_name = var_name.strip()
            expression = expression.strip()
            flex_env[var_name] = eval(expression, {}, flex_env)
        except Exception as e:
            print(f"[Runtime Error] Failed to assign variable: {e}")
    elif line.startswith("dbug "):
        try:
            varname = line.split(" ", 1)[1].strip()
            if varname in flex_env:
                print(f"[Debug] {varname} = {flex_env[varname]}")
            else:
                print(f"[Debug] {varname} is not defined")
        except Exception as e:
            print(f"[Runtime Error] dbug failed: {e}")
    elif line.startswith("saytxt(") or line.startswith("saynum(") or line.startswith("inputplyr(") or line.endswith(")"):
        try:
            eval(line, {}, flex_env)
        except Exception as e:
            print(f"[Runtime Error] {e}")
    elif line:
        print(f"[Syntax Error] Unknown command: {line}")

def run_flex_code(code):
    lines = code.strip().splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()

        if line.startswith("Lpp "):
            try:
                count = int(line.split(" ")[1])
                i += 1
                block, end_index = parse_block(lines, i)
                for _ in range(count):
                    for bline in block:
                        run_line(bline)
                i = end_index
            except Exception as e:
                print(f"[Runtime Error] Lpp error: {e}")

        elif line.startswith("TimerLpp "):
            try:
                count = int(line.split(" ")[1])
                i += 1
                block, end_index = parse_block(lines, i)
                for _ in range(count):
                    for bline in block:
                        run_line(bline)
                    time.sleep(1)
                i = end_index
            except Exception as e:
                print(f"[Runtime Error] TimerLpp error: {e}")

        elif line.startswith("DecTimer "):
            try:
                start = int(line.split(" ")[1])
                i += 1
                block, end_index = parse_block(lines, i)
                for timer in range(start, -1, -1):
                    flex_env['timer'] = timer
                    for bline in block:
                        run_line(bline)
                    time.sleep(1)
                i = end_index
            except Exception as e:
                print(f"[Runtime Error] DecTimer error: {e}")

        elif line.startswith("IncTimer "):
            try:
                parts = line.replace("IncTimer", "").strip().split("to")
                start = int(parts[0].strip())
                end = int(parts[1].strip())
                i += 1
                block, end_index = parse_block(lines, i)
                for timer in range(start, end + 1):
                    flex_env['timer'] = timer
                    for bline in block:
                        run_line(bline)
                    time.sleep(1)
                i = end_index
            except Exception as e:
                print(f"[Runtime Error] IncTimer error: {e}")

        elif line.startswith("CustomCD"):
            try:
                def_part = line.replace("CustomCD", "").strip()
                name_args, rest = def_part.split("(", 1)
                name = name_args.strip()
                args = rest.split(")")[0].strip()
                arg_list = [arg.strip() for arg in args.split(",") if arg.strip()]
                i += 1
                block, end_index = parse_block(lines, i)

                def custom_fn(*fn_args):
                    local_env = flex_env.copy()
                    for idx, val in enumerate(fn_args):
                        if idx < len(arg_list):
                            local_env[arg_list[idx]] = val
                    for bline in block:
                        try:
                            eval(bline, {}, local_env)
                        except Exception as e:
                            print(f"[Runtime Error in function '{name}']: {e}")

                flex_env[name] = custom_fn
                i = end_index
            except Exception as e:
                print(f"[Runtime Error] CustomCD error: {e}")
        else:
            run_line(line)
        i += 1

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python flex_interpreter.py file.flex")
        sys.exit(1)

    filepath = sys.argv[1]
    try:
        with open(filepath, 'r') as f:
            flex_code = f.read()
            run_flex_code(flex_code)
    except FileNotFoundError:
        print(f"File not found: {filepath}")

 