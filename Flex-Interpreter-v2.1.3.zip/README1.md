# Flex Interpreter v2.1.3

New Version Released. Want to see the New Features?. first, i will introduce you what is Flex:

Flex is an New Programming language that are Simple, Easy to use, Flexible and Lightweight. Flex is 
good for you who want's an Easy and Simple Programming language. also Flex makes you more Easier at
coding.

## New Syntax

-TimerLpp
-DecTimer
-IncTimer

## New Built-in Library

-AutoInput
-TXTtoNUM
-PopUPMes

## Example

saytxt("Welcome to Flex!")
load TXTtoNUM

let number = convert("123")
saynum(number)

load AutoInput
let answer = reply("How are you")
saytxt(answer)

load PopUPMes
alert("System are in danger!")

for more information abou the New Features, please open or check the changelog file.

## Creator

created by CodeJump56 
